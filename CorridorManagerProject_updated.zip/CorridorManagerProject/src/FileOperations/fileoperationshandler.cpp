#include "fileoperationshandler.h"

#include <QStandardPaths>
#include <QDir>
#include <QFile>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QDebug>
#include <QString>

FileOperationsHandler::FileOperationsHandler(QObject *parent)
    : QObject{parent}
{
    m_savedRoutesListModel = new SavedRoutesListModel( this );
    QString dataPath = QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation);
    m_dataPath = dataPath;

    QDir dir(dataPath);
    if (!dir.exists()) {
        dir.mkpath(".");
    }

    QString DirPath = dataPath + "/Drones";

    readSavedRoutes();
}

FileOperationsHandler::~FileOperationsHandler()
{
    m_savedRoutesListModel->deleteLater();
}

bool FileOperationsHandler::saveWayPoints(const QString &name, const  & /*selectedDrone*/,
                                          const QList<MarkerAbstractListModel::MarkerParams> &wayPoints)
{
    // Check if the file already exists
    QFile file(m_dataPath + QDir::separator() + name + ".json");
    if (file.exists()) {
        return false;
    }

    QJsonObject routeParams;
    int wayPointCount = 0;
    double totalDistance = 0;

    QJsonArray waypointsArray;

    for (const auto &waypoint : wayPoints) {
        wayPointCount++;
        QJsonObject waypointObj;
        waypointObj["longitude"] = waypoint.m_longitude;
        waypointObj["latitude"] = waypoint.m_latitude;
        waypointObj["totalDistanceTraveled"] = waypoint.m_totalDistanceTraveled;

        waypointsArray.append(waypointObj);

        totalDistance = waypoint.m_totalDistanceTraveled;
    }

    routeParams["totalWayPoints"] = wayPointCount;
    routeParams["totalDistance"] = totalDistance;

    QJsonObject mainObj;
    mainObj["quickdata"] = routeParams;
    mainObj["waypoints"] = waypointsArray;

    QJsonDocument doc(mainObj);

    if (!file.open(QIODevice::WriteOnly)) {
        return false;
    }

    file.write(doc.toJson());
    file.close();

    readSavedRoutes();

    return true;
}

void FileOperationsHandler::saveDrone(const  &)
{
    QFile File( m_dataPath + QDir::separator() + "Drones" + QDir::separator() +  + ".json" );

    qDebug() << m_dataPath + QDir::separator() + "Drones" + QDir::separator() +  + ".json";

    if ( File.exists() )
    {
        qWarning() << "Drone file already exists...";
        return;
    }

    if ( !File.open( QIODevice::WriteOnly ) )
    {
        qWarning() << "Cannot open  file for writing...";
        return;
    }

    QJsonObject JsonObject;
    JsonObject["name"] = ;
    JsonObject["maxTime"] = ;

    QJsonDocument jsonDoc(JsonObject);
    File.write( jsonDoc.toJson() );
    File.flush();
    File.close();
}

void FileOperationsHandler::readSavedRoutes()
{
    QList< SavedRoutesListModel::RouteQuickData > savedRoutes;

    QDir savedDir( m_dataPath );
    QStringList jsonFiles = savedDir.entryList(QStringList() << "*.json", QDir::Files);

    foreach (const QString &fileName, jsonFiles) {
        QFile routeFile(savedDir.filePath(fileName));
        if (!routeFile.open(QIODevice::ReadOnly)) {
            qWarning() << "Failed to open file:" << fileName;
            continue;
        }

        QByteArray fileData = routeFile.readAll();
        routeFile.close();

        QString routeName = fileName;
        routeName = routeName.replace(".json", "");

        QJsonDocument doc = QJsonDocument::fromJson(fileData);
        if (doc.isNull()) {
            qWarning() << "Failed to parse the file:" << fileName;
            continue;
        }

        QJsonObject routeJsonObject = doc.object();
        SavedRoutesListModel::RouteQuickData routeData(
            routeName,
            routeJsonObject[""].toObject()["name"].toString(),
            routeJsonObject["quickdata"].toObject()["totalDistance"].toDouble(),
            routeJsonObject["quickdata"].toObject()["totalTime"].toDouble(),
            routeJsonObject["waypoints"].toArray().count()
            );

        qDebug() << routeName<< routeJsonObject[""].toObject()["name"].toString() <<
            routeJsonObject["quickdata"].toObject()["totalDistance"].toDouble() <<
            routeJsonObject["quickdata"].toObject()["totalTime"].toDouble() <<
            routeJsonObject["waypoints"].toArray().count();

        savedRoutes.append( routeData );
    }

    m_savedRoutesListModel->loadRouteList( savedRoutes );
}

void FileOperationsHandler::removeSavedRoute(const QString &routeName)
{
    QString filePath = m_dataPath + QDir::separator() + routeName + ".json";

    // Check if the file exists
    QFile routeFile(filePath);
    if (!routeFile.exists()) {
        qWarning() << "Route file does not exist:" << filePath;
        return;
    }

    // Remove the file
    if (!routeFile.remove()) {
        qWarning() << "Failed to remove route file:" << filePath;
        return;
    }

    readSavedRoutes();
}

QList<> FileOperationsHandler::getSavedDrones()
{
    QList<> s;

    QDir directory(m_dataPath + QDir::separator() + "Drones");
    QStringList jsonFiles = directory.entryList(QStringList() << "*.json", QDir::Files);
    foreach (const QString &fileName, jsonFiles) {
        QFile File(directory.filePath(fileName));
        if (!File.open(QIODevice::ReadOnly)) {
            qWarning() << "Failed to open file:" << fileName;
            continue;
        }

        QByteArray fileData = File.readAll();
        File.close();

        QJsonDocument doc = QJsonDocument::fromJson(fileData);
        if (doc.isNull()) {
            qWarning() << "Failed to parse the file:" << fileName;
            continue;
        }

        QJsonObject JsonObject = doc.object();
         (
            JsonObject["name"].toString(),
            JsonObject["maxSpeed"].toInt(),
            JsonObject["maxTime"].toInt()
            );

        s.append();
    }

    return s;
}

void FileOperationsHandler::loadRoute(const QString &fileName)
{
    QString filePath = m_dataPath + QDir::separator() + fileName + ".json";

    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "Failed to open" << filePath;
        return;
    }

    QByteArray fileData = file.readAll();
    file.close();

    QJsonDocument doc = QJsonDocument::fromJson(fileData);
    if (doc.isNull()) {
        qWarning() << "Failed to parse the file:" << filePath;
        return;
    }

    QJsonObject mainObj = doc.object();
    QJsonArray waypointsArray = mainObj.value("waypoints").toArray();

    QList<MarkerAbstractListModel::MarkerParams> wayPointList;
    for (const QJsonValue &value : waypointsArray) {
        QJsonObject waypointObj = value.toObject();
        MarkerAbstractListModel::MarkerParams currentWayPoint(
            waypointObj.value("latitude").toDouble(),
            waypointObj.value("longitude").toDouble(),
            0, //  is not saved, so default to 0 or another appropriate value
            waypointObj.value("totalDistanceTraveled").toDouble(),
            0); // totalTimeTraveled is not saved, so default to 0 or another appropriate value

        wayPointList.append(currentWayPoint);
    }

    emit newWayPointsLoaded(wayPointList);
}
